# Destructuring assignment - Exercise 3
Utilizzare la destrutturazione per semplificare il controllo sull'età della persona.