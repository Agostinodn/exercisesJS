# Browser Storing Data - Exercise 1
Implementare il codice necessario per:
* Recuperare il post presente al seguente url: https://jsonplaceholder.typicode.com/posts/1 al click del pulsante "Fetch Post"
* Salvare il post sul localStorage al click del pulsante "Save Post on LocalStorage"